1- run command "npm install" to install dependancies.\
2- use Expo Go app for iOS or Android to open app being served through Expo CLI\
3- run command "expo start"\
4- scan QR code from Expo app