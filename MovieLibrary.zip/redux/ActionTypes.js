export const MOVIES_LOADING = 'MOVIES_LOADING';
export const ADD_MOVIES = 'ADD_MOVIES';
export const MOVIES_FAILED = 'MOVIES_FAILED';
